import React, { useState, useEffect} from 'react';
import ReactApexChart from "react-apexcharts";
import './CourseDesc.css';

// Will check if the course has been completed before or not
function IsNew(status){
    if (status){
        return true;
    }
    else {
        return false;
    }
}

function CourseDesc(props) {

    return (
    <>
    <div className='course-title'>
        <h1 className='title-heading'>{props.coursetitle}</h1>
        
        <img src={props.img} className="display-img" />
        <div className='course-desc'>
            <p>{props.coursedesc}</p>
        </div>
    </div>

    {IsNew(props.status) ? 
    <div className='bottom'>
        <p className='price'><span>Price = </span>$5 <span>only</span></p>
        <button className="buy-btn">
            <h4>Buy Course</h4>                   
        </button>
    </div>
    :
    <div className='bar-parent'>
        <div className='bar-child'>
            <span className='bar-text'>{`${props.progress}%`}</span>
        </div>
    </div>
    }
            
    </>
  );
}

export default CourseDesc;